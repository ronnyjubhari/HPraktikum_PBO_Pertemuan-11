/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hprak_pert11;

import java.awt.*;
/**
 *
 * @author RECKY
 */
public class HPrak_Pert11 extends Panel{
    
    Font f;
    String text = "Ini mobil dan nama saya Ronny Jubhari";
    HPrak_Pert11(){
        setBackground(Color.white);
    }
    
    public void paint(Graphics g) {
        int[] x = {50, 420, 420, 530, 530, 50};
        int[] y = {50, 50, 130, 130, 230, 230};
        g.setColor(new Color(51, 153, 255));

        Polygon pol = new Polygon(x, y, 6);
        g.fillPolygon(pol);
        
        g.setColor(Color.red);
        g.fillOval(130, 180, 100, 100);
        g.fillOval(330, 180, 100, 100);
        
        f = new Font("Helvetica",Font.BOLD,20);
        g.setFont(f);
        g.setColor(Color.black);
        g.drawString(text, 120, 320);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame f = new Frame("Desain Mobil Dengan Java Graphics");
        HPrak_Pert11 dm = new HPrak_Pert11();
        f.add(dm);
        f.setSize(600, 450);
        f.setVisible(true);
    }
    
}
